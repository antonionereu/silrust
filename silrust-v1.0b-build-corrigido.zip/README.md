# silrust v1.0b — Android ARM64

Base RustDesk 1.5.0, commit `e9ddbd8f460dac1b30b9815ba324a5dadc8d97b0`.

## Compilação

Colocar o conteúdo deste pacote na raiz do repositório, incluindo `.github` e `android`.
O envio dos ficheiros Android inicia o workflow **Build silrust Android**.
Também pode ser iniciado em Actions > Build silrust Android > Run workflow.
No final, descarregar o artefacto `silrust-v1.0b-arm64`.
A APK fica em `dist/silrust-v1.0b-arm64.apk` durante o build.

Esta é uma compilação release com assinatura debug para testes, não uma versão
assinada para distribuição. Mantém o applicationId original do RustDesk;
não instala por cima da versão oficial assinada com outra chave.

## Alterações

- Nome Android silrust.
- Controlos flutuantes: teclado, clipboard, ações originais e terminar sessão.
- Barra de modificadores oculta no Android.
- Histórico local de clipboard por computador remoto, até 40 entradas.
- Envio de texto pelo método Unicode existente no RustDesk.

O protocolo e o núcleo Rust não são alterados. O servidor continua configurável:
ID Server `silvending.ddns.net`, Relay vazio e a chave pública do teu hbbs.

## Validação

O patch foi aplicado localmente ao código original fixado acima.
O workflow gera a bridge, analisa os ficheiros Dart alterados, compila Rust e
Flutter e verifica a assinatura da APK. A compilação e os testes em dispositivo
só estão confirmados após a execução bem-sucedida e a validação manual.
Ver `TEST-PLAN.md` para teclado, acentos, ligação, áudio e clipboard.

## Âmbito das alterações ao RustDesk

- `flutter/lib/mobile/pages/remote_page.dart`: integra os controlos Android,
  oculta a barra auxiliar e reutiliza ações e encerramento existentes.
- `flutter/android/app/src/main/AndroidManifest.xml`: altera o nome visível.
- `flutter/pubspec.yaml`: acrescenta shared_preferences apenas se necessário.
- `flutter/android/app/build.gradle`: usa assinatura debug para a APK de testes.
- `flutter/android/gradle.properties`: aumenta a memória disponível ao Gradle.

O código RustDesk mantém a licença AGPL-3.0 presente no upstream. Os ficheiros
de bridge são gerados a partir do mesmo código durante a compilação.
