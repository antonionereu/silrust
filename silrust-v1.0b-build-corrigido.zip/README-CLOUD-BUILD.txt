SILRUST v1.0b — CLOUD BUILD

Consultar README.md.
A compilação corre no GitHub Actions; não requer WSL nem Android Studio no PC.
