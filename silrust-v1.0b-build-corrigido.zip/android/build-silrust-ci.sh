#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:?project root missing}"
TOOLS="$ROOT/.tools"
WORK="$ROOT/work"
SRC="$WORK/rustdesk"
DIST="$ROOT/dist"

RUSTDESK_REF="e9ddbd8f460dac1b30b9815ba324a5dadc8d97b0"
FLUTTER_REF="3.24.5"
RUST_VERSION="1.75.0"
CARGO_NDK_VERSION="3.1.2"
NDK_VERSION="28.2.13676358"
VCPKG_COMMIT="9e593bb18ea69cc5095e012465dcd675a822ed0d"

say(){ printf "\n\033[1;36m==> %s\033[0m\n" "$*"; }

mkdir -p "$TOOLS" "$WORK" "$DIST"

say "Linux dependencies"
sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y \
  git curl wget unzip zip ca-certificates \
  build-essential cmake ninja-build nasm yasm pkg-config \
  clang llvm libclang-dev libssl-dev \
  python3 python3-pip python3-setuptools libgtk-3-dev libasound2-dev libpulse-dev libxdo-dev libva-dev libclang-dev autoconf automake libtool \
  openjdk-17-jdk jq rsync patchelf

export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export PATH="$JAVA_HOME/bin:$PATH"

say "Android SDK"
SDK="$TOOLS/android-sdk"
mkdir -p "$SDK/cmdline-tools"

if [[ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]]; then
  ZIP="$TOOLS/cmdline-tools.zip"
  curl -L --fail --retry 3 \
    "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" \
    -o "$ZIP"
  rm -rf "$TOOLS/cmdline-unpack"
  mkdir -p "$TOOLS/cmdline-unpack"
  unzip -q "$ZIP" -d "$TOOLS/cmdline-unpack"
  rm -rf "$SDK/cmdline-tools/latest"
  mv "$TOOLS/cmdline-unpack/cmdline-tools" "$SDK/cmdline-tools/latest"
fi

export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
export PATH="$SDK/cmdline-tools/latest/bin:$SDK/platform-tools:$PATH"

yes | sdkmanager --licenses >/dev/null || true
sdkmanager \
  "platform-tools" \
  "platforms;android-36" \
  "build-tools;36.0.0" \
  "ndk;$NDK_VERSION"

export ANDROID_NDK_HOME="$SDK/ndk/$NDK_VERSION"
export ANDROID_NDK_ROOT="$ANDROID_NDK_HOME"

say "Rust $RUST_VERSION"
if [[ ! -x "$HOME/.cargo/bin/rustup" ]]; then
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs \
    | sh -s -- -y --default-toolchain "$RUST_VERSION"
fi
source "$HOME/.cargo/env"
rustup toolchain install "$RUST_VERSION"
rustup default "$RUST_VERSION"
rustup target add aarch64-linux-android

if ! cargo ndk --version 2>/dev/null | grep -q "$CARGO_NDK_VERSION"; then
  cargo install cargo-ndk --version "$CARGO_NDK_VERSION" --locked --force
fi

say "Flutter $FLUTTER_REF"
FLUTTER="$TOOLS/flutter"
if [[ ! -d "$FLUTTER/.git" ]]; then
  git clone --depth 1 --branch "$FLUTTER_REF" \
    https://github.com/flutter/flutter.git "$FLUTTER"
else
  git -C "$FLUTTER" fetch --depth 1 origin "$FLUTTER_REF"
  git -C "$FLUTTER" checkout -f "$FLUTTER_REF"
fi
export PATH="$FLUTTER/bin:$PATH"
flutter config --no-analytics >/dev/null
flutter precache --android

say "vcpkg"
VCPKG="$TOOLS/vcpkg"
if [[ ! -d "$VCPKG/.git" ]]; then
  git clone https://github.com/microsoft/vcpkg.git "$VCPKG"
fi
git -C "$VCPKG" fetch origin "$VCPKG_COMMIT" --depth 1
git -C "$VCPKG" checkout -f "$VCPKG_COMMIT"
"$VCPKG/bootstrap-vcpkg.sh" -disableMetrics
export VCPKG_ROOT="$VCPKG"

say "RustDesk $RUSTDESK_REF"
rm -rf "$SRC"
git init "$SRC"
git -C "$SRC" remote add origin https://github.com/rustdesk/rustdesk.git
git -C "$SRC" fetch --depth 1 origin "$RUSTDESK_REF"
git -C "$SRC" checkout --detach FETCH_HEAD
git -C "$SRC" submodule update --init --recursive --depth 1

# RustDesk 1.5.0 expects this Flutter patch on the 3.24 line.
FLUTTER_PATCH="$SRC/.github/patches/flutter_3.24.4_dropdown_menu_enableFilter.diff"
if [[ -f "$FLUTTER_PATCH" ]]; then
  if git -C "$FLUTTER" apply --check "$FLUTTER_PATCH" >/dev/null 2>&1; then
    git -C "$FLUTTER" apply "$FLUTTER_PATCH"
  fi
fi

say "Apply silrust patch"
python3 "$ROOT/android/patch_silrust.py" "$SRC"

say "Flutter packages"
pushd "$SRC/flutter"
flutter clean
flutter pub get
popd

say "Generate Flutter Rust bridge"
cargo install cargo-expand --version 1.0.95 --locked
cargo install flutter_rust_bridge_codegen --version 1.80.1 --features uuid --locked
pushd "$SRC"
flutter_rust_bridge_codegen --rust-input ./src/flutter_ffi.rs --dart-output ./flutter/lib/generated_bridge.dart --c-output ./flutter/macos/Runner/bridge_generated.h
cp flutter/macos/Runner/bridge_generated.h flutter/ios/Runner/bridge_generated.h
popd

say "Check silrust Dart code"
pushd "$SRC/flutter"
dart analyze --no-fatal-warnings --no-fatal-infos --no-fatal-infos lib/mobile/pages/remote_page.dart lib/mobile/widgets/silrust_controls.dart lib/mobile/widgets/silrust_clipboard.dart
popd

say "Android native dependencies"
pushd "$SRC"
bash flutter/build_android_deps.sh arm64-v8a

say "Rust core"
cargo ndk \
  --platform 21 \
  --target aarch64-linux-android \
  build \
  --locked \
  --release \
  --features "flutter,hwcodec"

JNI="$SRC/flutter/android/app/src/main/jniLibs/arm64-v8a"
mkdir -p "$JNI"

cp \
  "$SRC/target/aarch64-linux-android/release/liblibrustdesk.so" \
  "$JNI/librustdesk.so"

LIBCPP="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/sysroot/usr/lib/aarch64-linux-android/libc++_shared.so"
if [[ ! -f "$LIBCPP" ]]; then
  LIBCPP="$(find "$ANDROID_NDK_HOME" -name libc++_shared.so -path '*aarch64*' -print -quit)"
fi
test -f "$LIBCPP"
cp "$LIBCPP" "$JNI/libc++_shared.so"

STRIP="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip"
if [[ -x "$STRIP" ]]; then
  "$STRIP" "$JNI/librustdesk.so" || true
fi

say "Flutter APK"
pushd "$SRC/flutter"
sed -i 's/signingConfigs.release/signingConfigs.debug/g' android/app/build.gradle
sed -i 's/org.gradle.jvmargs=-Xmx1024M/org.gradle.jvmargs=-Xmx2g/g' android/gradle.properties
flutter build apk --release --target-platform android-arm64
popd

APK="$SRC/flutter/build/app/outputs/flutter-apk/app-release.apk"
test -f "$APK"

cp "$APK" "$DIST/silrust-v1.0b-arm64.apk"

say "Done"
ls -lh "$DIST/silrust-v1.0b-arm64.apk"
sha256sum "$DIST/silrust-v1.0b-arm64.apk"

"$SDK/build-tools/36.0.0/apksigner" verify --verbose "$DIST/silrust-v1.0b-arm64.apk"
