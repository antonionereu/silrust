import 'package:flutter/material.dart';

typedef SilrustAsyncCallback = Future<void> Function();

class SilrustControls extends StatefulWidget {
  const SilrustControls({
    super.key,
    required this.onEnd,
    required this.onScreen,
    required this.onKeyboard,
    required this.onInputMode,
    required this.onChat,
    required this.onMore,
    required this.onClipboard,
    required this.showKeyboard,
    required this.showInputMode,
    required this.peerAndroid,
    required this.touchMode,
  });

  final VoidCallback onEnd;
  final VoidCallback onScreen;
  final VoidCallback onKeyboard;
  final VoidCallback onInputMode;
  final SilrustAsyncCallback onChat;
  final VoidCallback onMore;
  final VoidCallback onClipboard;
  final bool showKeyboard;
  final bool showInputMode;
  final bool peerAndroid;
  final bool touchMode;

  @override
  State<SilrustControls> createState() => _SilrustControlsState();
}

class _SilrustControlsState extends State<SilrustControls> {
  bool collapsed = false;

  Widget button(
    IconData icon,
    String tooltip,
    VoidCallback onTap, {
    bool danger = false,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.5),
      child: Tooltip(
        message: tooltip,
        child: Material(
          color: danger
              ? const Color(0xB0A51D28)
              : const Color(0xA0181A1F),
          shape: const CircleBorder(),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: onTap,
            customBorder: const CircleBorder(),
            child: SizedBox(
              width: 42,
              height: 42,
              child: Icon(icon, color: Colors.white, size: 21),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final inputIcon = widget.peerAndroid
        ? Icons.build
        : (widget.touchMode ? Icons.touch_app : Icons.mouse);
    final inputTooltip = widget.peerAndroid ? 'Ações Android' : 'Rato / toque';

    return SafeArea(
      minimum: const EdgeInsets.only(right: 6),
      child: Align(
        alignment: Alignment.centerRight,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (!collapsed) ...[
              // Same order/actions as the original RustDesk bottom toolbar.
              button(Icons.clear, 'Terminar', widget.onEnd, danger: true),
              button(Icons.tv, 'Ecrã', widget.onScreen),
              if (widget.showKeyboard)
                button(Icons.keyboard, 'Teclado', widget.onKeyboard),
              // Only SilRust addition to the transported toolbar.
              button(Icons.content_paste_outlined, 'Clipboard', widget.onClipboard),
              if (widget.showInputMode)
                button(inputIcon, inputTooltip, widget.onInputMode),
              button(Icons.message_outlined, 'Texto / voz', () {
                widget.onChat();
              }),
              button(Icons.more_vert, 'Mais', widget.onMore),
            ],
            button(
              collapsed ? Icons.chevron_left : Icons.chevron_right,
              collapsed ? 'Mostrar controlos' : 'Ocultar controlos',
              () => setState(() => collapsed = !collapsed),
            ),
          ],
        ),
      ),
    );
  }
}
