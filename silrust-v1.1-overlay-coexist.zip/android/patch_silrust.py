#!/usr/bin/env python3
from __future__ import annotations

import re
import shutil
import sys
from pathlib import Path

if len(sys.argv) != 2:
    raise SystemExit("Uso: patch_silrust.py <rustdesk-source>")

root = Path(sys.argv[1]).resolve()
flutter = root / "flutter"
remote = flutter / "lib/mobile/pages/remote_page.dart"
pubspec = flutter / "pubspec.yaml"
manifest = flutter / "android/app/src/main/AndroidManifest.xml"
widgets = flutter / "lib/mobile/widgets"

for p in (remote, pubspec, manifest):
    if not p.exists():
        raise SystemExit(f"Falta upstream esperado: {p}")

text = remote.read_text(encoding="utf-8")

for anchor in [
    "class _RemotePageState",
    "void openKeyboard()",
    "class _KeyHelpToolsState",
    "Widget build(BuildContext context)",
    "bottomNavigationBar: Obx(() => Stack(",
    "void showActions(String id)",
    "showChatOptions(String id)",
]:
    if anchor not in text:
        raise SystemExit(f"Anchor RustDesk 1.5.0 nao encontrado: {anchor}")

widgets.mkdir(parents=True, exist_ok=True)
overlay = Path(__file__).parent / "overlay"
shutil.copy2(overlay / "silrust_controls.dart", widgets / "silrust_controls.dart")
shutil.copy2(overlay / "silrust_clipboard.dart", widgets / "silrust_clipboard.dart")

# Clipboard shelf persistence.
ps = pubspec.read_text(encoding="utf-8")
if not re.search(r"^\s*shared_preferences\s*:", ps, re.M):
    m = re.search(r"^dependencies:\s*$", ps, re.M)
    if not m:
        raise SystemExit("dependencies: nao encontrado")
    ps = ps[:m.end()] + "\n  shared_preferences: 2.3.2" + ps[m.end():]

# Public SilRust version. Keep Android versionCode above RustDesk 1.5.0 (+68)
# so v1.1 can replace the first SilRust test build in-place when the signature matches.
ps = re.sub(r"^version:\s*[^\n]+$", "version: 1.1.0+101", ps, count=1, flags=re.M)
pubspec.write_text(ps, encoding="utf-8")

# Launcher/app name only. Keep RustDesk package/namespace unchanged because SilRust is
# the only Android client installed and this avoids unnecessary native breakage.
ms = manifest.read_text(encoding="utf-8")
ms = ms.replace('android:label="RustDesk"', 'android:label="SilRust"')
manifest.write_text(ms, encoding="utf-8")

# SILRUST: applicationId próprio para poder coexistir com o RustDesk oficial.
# Mantemos o namespace/Kotlin upstream intacto para não partir MainActivity/services.
app_gradle = flutter / "android/app/build.gradle"
if not app_gradle.exists():
    raise SystemExit(f"Falta upstream esperado: {app_gradle}")
gs = app_gradle.read_text(encoding="utf-8")
old_app_id = 'applicationId "com.carriez.flutter_hbb"'
new_app_id = 'applicationId "com.silrust.remote"'
if old_app_id not in gs and new_app_id not in gs:
    raise SystemExit("applicationId RustDesk esperado não encontrado")
gs = gs.replace(old_app_id, new_app_id, 1)
app_gradle.write_text(gs, encoding="utf-8")


service_import = "import 'package:flutter/services.dart';"
if service_import not in text:
    raise SystemExit("flutter/services.dart import nao encontrado")
text = text.replace(
    service_import,
    service_import
    + "\nimport '../widgets/silrust_controls.dart';"
    + "\nimport '../widgets/silrust_clipboard.dart';",
    1,
)

# Remove the RustDesk Ctrl/Alt/Shift/Win/Fn helper strip above Android keyboard.
key_state = text.index("class _KeyHelpToolsState")
key_build = text.find("Widget build(BuildContext context)", key_state)
if key_build < 0:
    raise SystemExit("_KeyHelpToolsState.build nao encontrado")
key_brace = text.find("{", key_build)
if key_brace < 0:
    raise SystemExit("brace de KeyHelpTools.build nao encontrado")
text = (
    text[: key_brace + 1]
    + "\n    return const SizedBox.shrink(); // SILRUST: helper toolbar removida\n"
    + text[key_brace + 1 :]
)

# Fullscreen sticky instead of a one-shot manual hide. Keyboard logic can still
# temporarily show system overlays and on close they are restored by upstream.
text = text.replace(
    "SystemChrome.setEnabledSystemUIMode(SystemUiMode.manual, overlays: []);",
    "SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);",
)

# The bottom blue RustDesk toolbar is no longer laid out. Its same actions are
# exposed by SilrustControls on the right side.
bn_start = text.index("          bottomNavigationBar: Obx(() => Stack(")
body_start = text.index("          body: Obx(", bn_start)
text = text[:bn_start] + "          bottomNavigationBar: null,\n" + text[body_start:]

# Helpers inserted immediately before openKeyboard().
open_keyboard = text.find("  void openKeyboard()")
if open_keyboard < 0:
    raise SystemExit("openKeyboard anchor nao encontrado")

helpers = r'''
  Future<void> _silrustPaste(String value) async {
    if (value.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: value));
    await gFFI.invokeMethod("try_sync_clipboard");
    await Future.delayed(const Duration(milliseconds: 80));
    final isMac = gFFI.ffiModel.pi.platform == kPeerPlatformMacOS;
    inputModel.inputKey(
      'VK_V',
      press: true,
      ctrlOverride: !isMac,
      commandOverride: isMac,
      altOverride: false,
      shiftOverride: false,
    );
  }

  void _silrustScreenOptions() {
    setState(() => _showEdit = false);
    showOptions(context, widget.id, gFFI.dialogManager);
  }

  void _silrustInputMode() {
    if (gFFI.ffiModel.isPeerAndroid) {
      gFFI.dialogManager.toggleMobileActionsOverlay(ffi: gFFI);
    } else {
      setState(() => _showGestureHelp = !_showGestureHelp);
    }
  }

  Future<void> _silrustChat() async {
    final isSupportVoiceCall =
        await gFFI.invokeMethod("get_value", "KEY_IS_SUPPORT_VOICE_CALL");
    if (isAndroid && isSupportVoiceCall == true) {
      showChatOptions(widget.id);
    } else {
      onPressedTextChat(widget.id);
    }
  }

  void _silrustMore() {
    setState(() => _showEdit = false);
    showActions(widget.id);
  }

  void _silrustEnd() {
    clientClose(sessionId, gFFI);
  }

'''
text = text[:open_keyboard] + helpers + text[open_keyboard:]

# Wrap only _RemotePageState.build. The RustDesk Scaffold/body remain unchanged;
# SilRust merely overlays the transported toolbar on the right.
state_start = text.index("class _RemotePageState")
build_pos = text.find("Widget build(BuildContext context)", state_start)
if build_pos < 0:
    raise SystemExit("_RemotePageState.build nao encontrado")

text = (
    text[:build_pos]
    + "Widget _silrustUpstreamBuild(BuildContext context)"
    + text[build_pos + len("Widget build(BuildContext context)") :]
)

wrapper = r'''
  @override
  Widget build(BuildContext context) {
    final upstream = _silrustUpstreamBuild(context);

    if (defaultTargetPlatform != TargetPlatform.android) {
      return upstream;
    }

    final ffiModel = Provider.of<FfiModel>(context);
    final showKeyboard =
        !isWebDesktop && !ffiModel.viewOnly && ffiModel.keyboard;
    final showInputMode = showKeyboard;

    return Stack(
      fit: StackFit.expand,
      children: [
        upstream,
        SilrustControls(
          onEnd: _silrustEnd,
          onScreen: _silrustScreenOptions,
          onKeyboard: openKeyboard,
          onInputMode: _silrustInputMode,
          onChat: _silrustChat,
          onMore: _silrustMore,
          onClipboard: () {
            SilrustClipboard.show(
              context,
              widget.id,
              _silrustPaste,
            );
          },
          showKeyboard: showKeyboard,
          showInputMode: showInputMode,
          peerAndroid: ffiModel.isPeerAndroid,
          touchMode: ffiModel.touchMode,
        ),
      ],
    );
  }

'''
text = text[:build_pos] + wrapper + text[build_pos:]

text = text.replace(
    "class _RemotePageState",
    "// SILRUST_V1_1\nclass _RemotePageState",
    1,
)

remote.write_text(text, encoding="utf-8")

(root / "SILRUST_PATCH.txt").write_text(
    "SilRust Android v1.1\n"
    "Base RustDesk 1.5.0\n"
    "Core/protocol unchanged.\n"
    "Native bottom toolbar transported to right floating column.\n"
    "Added SilRust clipboard shelf.\n"
    "Android session opens immersive fullscreen.\n",
    encoding="utf-8",
)

print("OK: patch SilRust Android v1.1 aplicado.")
