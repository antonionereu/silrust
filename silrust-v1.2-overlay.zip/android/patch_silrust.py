#!/usr/bin/env python3
from __future__ import annotations

import re
import shutil
import sys
from pathlib import Path

if len(sys.argv) != 2:
    raise SystemExit('Uso: patch_silrust.py <rustdesk-source>')

root = Path(sys.argv[1]).resolve()
flutter = root / 'flutter'
remote = flutter / 'lib/mobile/pages/remote_page.dart'
common = flutter / 'lib/common.dart'
pubspec = flutter / 'pubspec.yaml'
manifest = flutter / 'android/app/src/main/AndroidManifest.xml'
gradle = flutter / 'android/app/build.gradle'
main_activity = flutter / 'android/app/src/main/kotlin/com/carriez/flutter_hbb/MainActivity.kt'
rd_clipboard = flutter / 'android/app/src/main/kotlin/com/carriez/flutter_hbb/RdClipboardManager.kt'
widgets = flutter / 'lib/mobile/widgets'

for p in (remote, common, pubspec, manifest, gradle, main_activity, rd_clipboard):
    if not p.exists():
        raise SystemExit(f'Falta upstream esperado: {p}')


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise SystemExit(f'{label}: esperado 1 match, encontrados {count}')
    return text.replace(old, new, 1)


# ---------------------------------------------------------------------------
# Overlay files
# ---------------------------------------------------------------------------
widgets.mkdir(parents=True, exist_ok=True)
overlay = Path(__file__).parent / 'overlay'
for name in (
    'silrust_controls.dart',
    'silrust_clipboard.dart',
    'silrust_mouse_panel.dart',
):
    src = overlay / name
    if not src.exists():
        raise SystemExit(f'Overlay em falta: {src}')
    shutil.copy2(src, widgets / name)

# ---------------------------------------------------------------------------
# Dependency used by the persistent clipboard shelf
# ---------------------------------------------------------------------------
ps = pubspec.read_text(encoding='utf-8')
if not re.search(r'^\s*shared_preferences\s*:', ps, re.M):
    m = re.search(r'^dependencies:\s*$', ps, re.M)
    if not m:
        raise SystemExit('pubspec: dependencies: não encontrado')
    ps = ps[:m.end()] + '\n  shared_preferences: 2.3.2' + ps[m.end():]
pubspec.write_text(ps, encoding='utf-8')

# ---------------------------------------------------------------------------
# Branding + coexistence with official RustDesk Android
# Namespace stays upstream; applicationId is unique.
# ---------------------------------------------------------------------------
ms = manifest.read_text(encoding='utf-8')
ms = ms.replace('android:label="RustDesk"', 'android:label="silrust"')
manifest.write_text(ms, encoding='utf-8')

gs = gradle.read_text(encoding='utf-8')
if 'applicationId "pt.silrust.app"' not in gs:
    gs = replace_once(
        gs,
        'applicationId "com.carriez.flutter_hbb"',
        'applicationId "pt.silrust.app"',
        'applicationId',
    )
gradle.write_text(gs, encoding='utf-8')


# ---------------------------------------------------------------------------
# Allow SilRust panels based on CustomAlertDialog to choose their alignment.
# OverlayDialogManager's DialogBuilder deliberately returns CustomAlertDialog,
# so wrapping one in Align would fail static analysis. Add optional properties
# to the shared dialog instead, leaving all upstream callers unchanged.
# ---------------------------------------------------------------------------
cs = common.read_text(encoding='utf-8')
constructor_old = '''      this.contentPadding,
      this.contentBoxConstraints = const BoxConstraints(maxWidth: 500),
      this.onSubmit,
      this.onCancel})'''
constructor_new = '''      this.contentPadding,
      this.contentBoxConstraints = const BoxConstraints(maxWidth: 500),
      this.alignment,
      this.insetPadding,
      this.onSubmit,
      this.onCancel})'''
cs = replace_once(
    cs,
    constructor_old,
    constructor_new,
    'CustomAlertDialog constructor alignment',
)
fields_old = '''  final double? contentPadding;
  final BoxConstraints contentBoxConstraints;
  final Function()? onSubmit;'''
fields_new = '''  final double? contentPadding;
  final BoxConstraints contentBoxConstraints;
  final AlignmentGeometry? alignment;
  final EdgeInsets? insetPadding;
  final Function()? onSubmit;'''
cs = replace_once(
    cs,
    fields_old,
    fields_new,
    'CustomAlertDialog fields alignment',
)
alert_old = '''      child: AlertDialog(
          scrollable: true,
          title: title,'''
alert_new = '''      child: AlertDialog(
          scrollable: true,
          alignment: alignment,
          insetPadding: insetPadding,
          title: title,'''
cs = replace_once(
    cs,
    alert_old,
    alert_new,
    'CustomAlertDialog AlertDialog alignment',
)
common.write_text(cs, encoding='utf-8')

# ---------------------------------------------------------------------------
# Native Android clipboard listener
# RustDesk already receives remote clipboard changes in RdClipboardManager.
# We mirror text clipboard changes to a dedicated Flutter channel so the
# SilRust history is automatic: Ctrl+C / Copy -> history, no "+" button.
# ---------------------------------------------------------------------------
ma = main_activity.read_text(encoding='utf-8')
ma = replace_once(
    ma,
    '        var flutterMethodChannel: MethodChannel? = null\n        private var _rdClipboardManager: RdClipboardManager? = null',
    '        var flutterMethodChannel: MethodChannel? = null\n'
    '        var silrustClipboardChannel: MethodChannel? = null\n'
    '        private var _rdClipboardManager: RdClipboardManager? = null',
    'MainActivity companion clipboard channel',
)
ma = replace_once(
    ma,
    '        initFlutterChannel(flutterMethodChannel!!)\n        thread {',
    '        initFlutterChannel(flutterMethodChannel!!)\n'
    '        silrustClipboardChannel = MethodChannel(\n'
    '            flutterEngine.dartExecutor.binaryMessenger,\n'
    '            "silrust_clipboard_history"\n'
    '        )\n'
    '        thread {',
    'MainActivity create clipboard channel',
)
ma = replace_once(
    ma,
    '            _rdClipboardManager = RdClipboardManager(getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)\n'
    '            FFI.setClipboardManager(_rdClipboardManager!!)',
    '            _rdClipboardManager = RdClipboardManager(\n'
    '                getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager\n'
    '            ) { text ->\n'
    '                runOnUiThread {\n'
    '                    silrustClipboardChannel?.invokeMethod("changed", text)\n'
    '                }\n'
    '            }\n'
    '            FFI.setClipboardManager(_rdClipboardManager!!)',
    'MainActivity clipboard callback',
)
main_activity.write_text(ma, encoding='utf-8')

rc = rd_clipboard.read_text(encoding='utf-8')
rc = replace_once(
    rc,
    'class RdClipboardManager(private val clipboardManager: ClipboardManager) {',
    'class RdClipboardManager(\n'
    '    private val clipboardManager: ClipboardManager,\n'
    '    private val onSilrustTextChanged: (String) -> Unit = {}\n'
    ') {',
    'RdClipboardManager constructor',
)
rc = replace_once(
    rc,
    '    private val supportedMimeTypes = arrayOf(\n'
    '        ClipDescription.MIMETYPE_TEXT_PLAIN,\n'
    '        ClipDescription.MIMETYPE_TEXT_HTML\n'
    '    )',
    '    private val supportedMimeTypes = arrayOf(\n'
    '        ClipDescription.MIMETYPE_TEXT_PLAIN,\n'
    '        ClipDescription.MIMETYPE_TEXT_HTML\n'
    '    )\n\n'
    '    init {\n'
    '        clipboardManager.addPrimaryClipChangedListener {\n'
    '            val clipData = clipboardManager.primaryClip\n'
    '            if (clipData != null && clipData.itemCount > 0) {\n'
    '                val text = clipData.getItemAt(0).text?.toString()\n'
    '                if (!text.isNullOrBlank()) {\n'
    '                    onSilrustTextChanged(text)\n'
    '                }\n'
    '            }\n'
    '        }\n'
    '    }',
    'RdClipboardManager listener',
)
rd_clipboard.write_text(rc, encoding='utf-8')

# ---------------------------------------------------------------------------
# Remote-page UI patch (RustDesk 1.5.0)
# ---------------------------------------------------------------------------
text = remote.read_text(encoding='utf-8')

required = [
    'class _RemotePageState',
    'void openKeyboard()',
    'Widget getBodyForMobile()',
    'void showActions(String id) async',
    'void showOptions(',
    'KeyHelpTools(',
    'floatingActionButtonLocation:',
]
for anchor in required:
    if anchor not in text:
        raise SystemExit(f'Anchor RustDesk 1.5.0 não encontrado: {anchor}')

# Imports.
import_anchor = "import '../widgets/custom_scale_widget.dart';"
new_imports = """import '../widgets/custom_scale_widget.dart';
import '../widgets/silrust_controls.dart';
import '../widgets/silrust_clipboard.dart';
import '../widgets/silrust_mouse_panel.dart';"""
text = replace_once(text, import_anchor, new_imports, 'imports SilRust')

# Never show RustDesk's modifier/help strip above Android soft keyboard.
key_tools = """            KeyHelpTools(
                keyboardIsVisible: keyboardIsVisible,
                showGestureHelp: _showGestureHelp),"""
text = replace_once(
    text,
    key_tools,
    '            const SizedBox.shrink(), // SILRUST: sem Ctrl/Alt/Shift/Fn toolbar',
    'KeyHelpTools widget',
)

# Bottom RustDesk toolbar/gesture sheet is replaced by the right-side controls.
bottom_old = """  Widget _bottomWidget() => _showGestureHelp
      ? getGestureHelp()
      : (_showBar && gFFI.ffiModel.pi.displays.isNotEmpty
          ? getBottomAppBar()
          : Offstage());"""
text = replace_once(
    text,
    bottom_old,
    '  Widget _bottomWidget() => const SizedBox.shrink();',
    '_bottomWidget',
)

# Remove RustDesk's blue expand/down FAB. The side keyboard button now changes to ↓.
scaffold_anchor = text.index('      child: Scaffold(')
fab_start = text.index('          floatingActionButtonLocation:', scaffold_anchor)
fab_end = text.index('          bottomNavigationBar:', fab_start)
text = (
    text[:fab_start]
    + '          floatingActionButton: null, // SILRUST: controls live on the right side\n'
    + text[fab_end:]
)

# Add SilRust control helpers immediately before upstream openKeyboard().
open_keyboard = text.index('  void openKeyboard()')
helpers = r'''
  bool get _silrustKeyboardVisible =>
      keyboardVisibilityController.isVisible && _showEdit;

  void _silrustCloseKeyboard() {
    if (!_showEdit && !keyboardVisibilityController.isVisible) return;
    setState(() => _showEdit = false);
    gFFI.invokeMethod("enable_soft_keyboard", false);
    _mobileFocusNode.unfocus();
    _physicalFocusNode.requestFocus();
  }

  void _silrustToggleKeyboard() {
    if (_showEdit || keyboardVisibilityController.isVisible) {
      _silrustCloseKeyboard();
    } else {
      openKeyboard();
    }
  }

  Future<void> _silrustPaste(String value) async {
    if (value.isEmpty) return;

    Future<void> send() async {
      bind.sessionInputString(sessionId: sessionId, value: value);
    }

    final allowWaylandKeyboard =
        mainGetPeerBoolOptionSync(widget.id, kPeerOptionAllowWaylandKeyboard);
    if (shouldShowWaylandKeyboardPrompt(
      connectionId: sessionId.toString(),
      isWaylandPeer: _shouldGateKeyboardForWayland(),
      allowWaylandKeyboardRemembered: allowWaylandKeyboard,
    )) {
      inputModel.keyboardInputAllowed = false;
      showWaylandKeyboardInputWarningDialog(
        id: widget.id,
        connectionId: sessionId.toString(),
        ffi: gFFI,
        onEnable: send,
      );
      return;
    }
    await send();
  }

  Future<void> _silrustToggleFollow() async {
    const option = 'follow-remote-cursor';
    await bind.sessionToggleOption(sessionId: sessionId, value: option);
    final enabled =
        bind.sessionGetToggleOptionSync(sessionId: sessionId, arg: option);
    showToast(enabled ? 'SEGUIR ligado' : 'SEGUIR desligado');
  }

  Future<void> _silrustOneX() async {
    await bind.sessionSetViewStyle(
      sessionId: sessionId,
      value: kRemoteViewStyleOriginal,
    );
    gFFI.canvasModel.updateViewStyle();
    gFFI.cursorModel.reset();
  }

  void _silrustFiles() {
    final connToken = bind.sessionGetConnToken(sessionId: gFFI.sessionId);
    connect(
      context,
      widget.id,
      isFileTransfer: true,
      connToken: connToken,
    );
  }

  void _silrustMousePad() {
    SilrustMousePanel.toggle(
      context,
      touchMode: gFFI.ffiModel.touchMode,
      showVirtualMouse: gFFI.ffiModel.virtualMouseMode.showVirtualMouse,
      onMode: (touchMode) async {
        if (gFFI.ffiModel.touchMode != touchMode) {
          gFFI.ffiModel.toggleTouchMode();
          final v = gFFI.ffiModel.touchMode ? 'Y' : 'N';
          await bind.mainSetLocalOption(key: kOptionTouchMode, value: v);
          if (gFFI.ffiModel.touchMode) {
            gFFI.inputModel.setRelativeMouseMode(false);
          }
          if (mounted) setState(() {});
        }
      },
      onVirtualMouse: () async {
        await gFFI.ffiModel.virtualMouseMode.toggleVirtualMouse();
        if (!gFFI.ffiModel.virtualMouseMode.showVirtualMouse) {
          gFFI.inputModel.setRelativeMouseMode(false);
        }
        if (mounted) setState(() {});
      },
    );
  }

'''
text = text[:open_keyboard] + helpers + text[open_keyboard:]

# Add side controls as the final layer in the remote desktop Stack.
body_start = text.index('  Widget getBodyForMobile()')
body_end = text.index('  Widget getBodyForDesktopWithListener()', body_start)
body = text[body_start:body_end]
return_marker = '          return paints;'
if body.count(return_marker) != 1:
    raise SystemExit(
        f'getBodyForMobile: esperado 1 return paints, encontrados {body.count(return_marker)}'
    )
controls_add = r'''          paints.add(SilrustControls(
            touchMode: gFFI.ffiModel.touchMode,
            keyboardVisible: _silrustKeyboardVisible,
            recording: gFFI.recordingModel.start,
            onOptions: () {
              _silrustCloseKeyboard();
              showOptions(context, widget.id, gFFI.dialogManager);
            },
            onKeyboard: _silrustToggleKeyboard,
            onClipboard: () => SilrustClipboard.toggle(
              context,
              widget.id,
              _silrustPaste,
            ),
            onMousePad: _silrustMousePad,
            onFollow: _silrustToggleFollow,
            onOneX: _silrustOneX,
            onFiles: _silrustFiles,
            onRecord: () async {
              await gFFI.recordingModel.toggle();
              if (mounted) setState(() {});
            },
            onMore: () {
              _silrustCloseKeyboard();
              showActions(widget.id);
            },
            onEnd: () => clientClose(sessionId, gFFI),
          ));
          return paints;'''
body = body.replace(return_marker, controls_add, 1)
text = text[:body_start] + body + text[body_end:]

# Clean overlay entries when leaving the remote session.
dispose_anchor = '    WidgetsBinding.instance.removeObserver(this);'
text = replace_once(
    text,
    dispose_anchor,
    dispose_anchor
    + '\n    SilrustClipboard.stop(widget.id);'
    + '\n    SilrustMousePanel.dismiss();',
    'dispose overlays',
)

# Anchor RustDesk "More" popup next to the right-side menu, not bottom-left.
# Also applies the same anchor to chat options if that path is used.
menu_coords = """    final size = MediaQuery.of(context).size;
    final x = 120.0;
    final y = size.height;"""
menu_coords_new = """    final size = MediaQuery.of(context).size;
    final x = size.width - 70.0;
    final y = size.height * 0.52;"""
count = text.count(menu_coords)
if count < 1:
    raise SystemExit('showMenu: coordenadas upstream não encontradas')
text = text.replace(menu_coords, menu_coords_new)

menu_position = 'position: RelativeRect.fromLTRB(x, y, x, y),'
menu_position_new = (
    'position: RelativeRect.fromLTRB('
    'x, y, size.width - x, size.height - y),'
)
count = text.count(menu_position)
if count < 1:
    raise SystemExit('showMenu: RelativeRect upstream não encontrado')
text = text.replace(menu_position, menu_position_new)

# Move the Image/Scale/Quality/Codec panel from center to a fixed right-side rail.
options_old = """    return CustomAlertDialog(
      content: Column(
          mainAxisSize: MainAxisSize.min,
          children: displays +
              radios +
              popupDialogMenus +
              toggles +
              [privacyModeWidget]),
    );"""
options_new = """    return CustomAlertDialog(
      alignment: Alignment.centerRight,
      insetPadding: const EdgeInsets.only(
        left: 24,
        right: 58,
        top: 10,
        bottom: 10,
      ),
      contentBoxConstraints: BoxConstraints(
        maxWidth: 420,
        maxHeight: MediaQuery.of(context).size.height * 0.88,
      ),
      content: Column(
          mainAxisSize: MainAxisSize.min,
          children: displays +
              radios +
              popupDialogMenus +
              toggles +
              [privacyModeWidget]),
    );"""
text = replace_once(text, options_old, options_new, 'showOptions right rail')

# Marker for diagnostics.
text = text.replace(
    'class _RemotePageState extends State<RemotePage> with WidgetsBindingObserver {',
    '// SILRUST_V1_2\nclass _RemotePageState extends State<RemotePage> with WidgetsBindingObserver {',
    1,
)

remote.write_text(text, encoding='utf-8')

(root / 'SILRUST_PATCH.txt').write_text(
    'SilRust v1.2\n'
    'Base: RustDesk 1.5.0\n'
    'Android only. Core/protocol untouched.\n'
    'Clipboard auto-history + floating/draggable, dynamic keyboard close button, right-side panels; dialog alignment buildfix r3.\n',
    encoding='utf-8',
)

print('OK: SilRust v1.2 patch aplicado.')
