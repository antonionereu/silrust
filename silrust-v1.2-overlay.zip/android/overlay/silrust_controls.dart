import 'dart:async';

import 'package:flutter/material.dart';

class SilrustControls extends StatefulWidget {
  const SilrustControls({
    super.key,
    required this.touchMode,
    required this.keyboardVisible,
    required this.recording,
    required this.onOptions,
    required this.onKeyboard,
    required this.onClipboard,
    required this.onMousePad,
    required this.onFiles,
    required this.onRecord,
    required this.onMore,
    required this.onEnd,
  });

  final bool touchMode;
  final bool keyboardVisible;
  final bool recording;

  final VoidCallback onOptions;
  final VoidCallback onKeyboard;
  final VoidCallback onClipboard;
  final VoidCallback onMousePad;
  final VoidCallback onFiles;
  final VoidCallback onRecord;
  final VoidCallback onMore;
  final VoidCallback onEnd;

  @override
  State<SilrustControls> createState() => _SilrustControlsState();
}

class _SilrustControlsState extends State<SilrustControls> {
  static const _hideDelay = Duration(seconds: 3);

  Timer? _hideTimer;
  bool _visible = true;

  @override
  void initState() {
    super.initState();
    _armHideTimer();
  }

  @override
  void dispose() {
    _hideTimer?.cancel();
    super.dispose();
  }

  void _armHideTimer() {
    _hideTimer?.cancel();
    _hideTimer = Timer(_hideDelay, () {
      if (mounted && _visible) {
        setState(() => _visible = false);
      }
    });
  }

  void _showControls() {
    if (!_visible) {
      setState(() => _visible = true);
    }
    _armHideTimer();
  }

  void _invoke(VoidCallback action) {
    _showControls();
    action();
  }

  Widget _button(
    IconData icon,
    String tooltip,
    VoidCallback onTap, {
    bool danger = false,
    bool active = false,
    String? badge,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.5),
      child: Tooltip(
        message: tooltip,
        child: Material(
          color: danger
              ? const Color(0xBC9C2525)
              : active
                  ? const Color(0xC9136FDB)
                  : const Color(0xA816181C),
          borderRadius: BorderRadius.circular(21),
          elevation: 2,
          child: InkWell(
            onTap: () => _invoke(onTap),
            borderRadius: BorderRadius.circular(21),
            child: SizedBox(
              width: 43,
              height: 43,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  Icon(icon, color: Colors.white, size: 21),
                  if (badge != null)
                    Positioned(
                      right: 1,
                      bottom: 1,
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 3,
                          vertical: 1,
                        ),
                        decoration: BoxDecoration(
                          color: const Color(0xD9000000),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          badge,
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 7,
                            fontWeight: FontWeight.w700,
                            height: 1.0,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // When hidden there is no extra button. A narrow transparent hot-zone at
    // the right edge brings the eight controls back on tap/drag.
    if (!_visible) {
      return SafeArea(
        child: Align(
          alignment: Alignment.centerRight,
          child: GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTap: _showControls,
            onPanStart: (_) => _showControls(),
            child: const SizedBox(width: 16, height: 240),
          ),
        ),
      );
    }

    return SafeArea(
      child: Align(
        alignment: Alignment.centerRight,
        child: Padding(
          padding: const EdgeInsets.only(right: 7),
          child: GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTapDown: (_) => _armHideTimer(),
            onPanDown: (_) => _armHideTimer(),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _button(
                  Icons.close,
                  'Terminar',
                  widget.onEnd,
                  danger: true,
                ),
                _button(
                  Icons.monitor_outlined,
                  'Imagem / Codec',
                  widget.onOptions,
                ),
                _button(
                  widget.keyboardVisible
                      ? Icons.keyboard_arrow_down
                      : Icons.keyboard_alt_outlined,
                  widget.keyboardVisible ? 'Fechar teclado' : 'Teclado',
                  widget.onKeyboard,
                  active: widget.keyboardVisible,
                ),
                _button(
                  Icons.content_paste_outlined,
                  'Clipboard',
                  widget.onClipboard,
                ),
                _button(
                  widget.touchMode ? Icons.touch_app : Icons.mouse,
                  widget.touchMode ? 'PAD / Toque' : 'MOUSE',
                  widget.onMousePad,
                  badge: widget.touchMode ? 'PAD' : 'M',
                ),
                _button(
                  Icons.folder_open_outlined,
                  'Ficheiros',
                  widget.onFiles,
                ),
                _button(
                  widget.recording
                      ? Icons.stop_circle_outlined
                      : Icons.fiber_manual_record,
                  widget.recording ? 'Parar gravação' : 'REC',
                  widget.onRecord,
                  active: widget.recording,
                  badge: widget.recording ? 'STOP' : 'REC',
                ),
                _button(
                  Icons.more_horiz,
                  'Mais',
                  widget.onMore,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
