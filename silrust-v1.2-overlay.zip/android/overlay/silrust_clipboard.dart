import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SilrustClipboard {
  static const int maxItems = 40;
  static const MethodChannel _historyChannel =
      MethodChannel('silrust_clipboard_history');

  static OverlayEntry? _entry;
  static String? _activePeer;
  static bool _channelReady = false;
  static final ValueNotifier<int> revision = ValueNotifier<int>(0);

  static String _listKey(String peer) => 'silrust.clipboard.$peer';
  static String _xKey(String peer) => 'silrust.clipboard.x.$peer';
  static String _yKey(String peer) => 'silrust.clipboard.y.$peer';

  static Future<List<String>> load(String peer) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(_listKey(peer)) ?? <String>[];
  }

  static Future<List<String>> remember(String peer, String text) async {
    if (text.trim().isEmpty) return load(peer);
    final prefs = await SharedPreferences.getInstance();
    final list = await load(peer);
    list.remove(text);
    list.insert(0, text);
    while (list.length > maxItems) {
      list.removeLast();
    }
    await prefs.setStringList(_listKey(peer), list);
    return list;
  }

  static Future<void> start(String peer) async {
    _activePeer = peer;
    if (_channelReady) return;

    _historyChannel.setMethodCallHandler((call) async {
      if (call.method != 'changed') return;
      final peerId = _activePeer;
      final text = call.arguments is String ? call.arguments as String : '';
      if (peerId == null || text.trim().isEmpty) return;
      await remember(peerId, text);
      revision.value++;
    });
    _channelReady = true;
  }

  static void stop(String peer) {
    if (_activePeer == peer) {
      _activePeer = null;
    }
    dismiss();
  }

  static void dismiss() {
    _entry?.remove();
    _entry = null;
  }

  static Future<void> toggle(
    BuildContext context,
    String peer,
    Future<void> Function(String) onPaste,
  ) async {
    if (_entry != null) {
      dismiss();
      return;
    }

    final prefs = await SharedPreferences.getInstance();
    final items = await load(peer);
    if (!context.mounted) return;

    final overlay = Overlay.of(context, rootOverlay: true);
    final savedX = prefs.getDouble(_xKey(peer));
    final savedY = prefs.getDouble(_yKey(peer));

    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (ctx) => _SilrustClipboardWindow(
        peer: peer,
        initialItems: items,
        initialPosition: Offset(savedX ?? 12, savedY ?? 12),
        onPaste: onPaste,
        onClose: dismiss,
        onPosition: (offset) async {
          final p = await SharedPreferences.getInstance();
          await p.setDouble(_xKey(peer), offset.dx);
          await p.setDouble(_yKey(peer), offset.dy);
        },
      ),
    );

    _entry = entry;
    overlay.insert(entry);
  }
}

class _SilrustClipboardWindow extends StatefulWidget {
  const _SilrustClipboardWindow({
    required this.peer,
    required this.initialItems,
    required this.initialPosition,
    required this.onPaste,
    required this.onClose,
    required this.onPosition,
  });

  final String peer;
  final List<String> initialItems;
  final Offset initialPosition;
  final Future<void> Function(String) onPaste;
  final VoidCallback onClose;
  final Future<void> Function(Offset) onPosition;

  @override
  State<_SilrustClipboardWindow> createState() =>
      _SilrustClipboardWindowState();
}

class _SilrustClipboardWindowState extends State<_SilrustClipboardWindow> {
  late List<String> items;
  late Offset position;

  @override
  void initState() {
    super.initState();
    items = List<String>.from(widget.initialItems);
    position = widget.initialPosition;
    SilrustClipboard.revision.addListener(_reloadFromStore);
  }

  @override
  void dispose() {
    SilrustClipboard.revision.removeListener(_reloadFromStore);
    super.dispose();
  }

  Future<void> _reloadFromStore() async {
    final latest = await SilrustClipboard.load(widget.peer);
    if (!mounted) return;
    setState(() => items = latest);
  }

  Future<void> _saveItems() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList('silrust.clipboard.${widget.peer}', items);
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final padding = MediaQuery.paddingOf(context);

    final panelW = math.min(380.0, math.max(300.0, size.width * .31));
    final panelH = math.min(330.0, math.max(190.0, size.height * .52));

    final minX = 8.0;
    final maxX = math.max(minX, size.width - panelW - 62);
    final minY = padding.top + 8;
    final maxY = math.max(minY, size.height - panelH - 8);

    final x = position.dx.clamp(minX, maxX).toDouble();
    final y = position.dy.clamp(minY, maxY).toDouble();

    void move(DragUpdateDetails d) {
      setState(() {
        position = Offset(
          (x + d.delta.dx).clamp(minX, maxX).toDouble(),
          (y + d.delta.dy).clamp(minY, maxY).toDouble(),
        );
      });
    }

    return Positioned(
      left: x,
      top: y,
      width: panelW,
      height: panelH,
      child: Material(
        color: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xDC17191D),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white12),
            boxShadow: const [
              BoxShadow(
                color: Color(0x66000000),
                blurRadius: 18,
                offset: Offset(0, 7),
              ),
            ],
          ),
          child: Column(
            children: [
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onPanUpdate: move,
                onPanEnd: (_) => widget.onPosition(position),
                child: Container(
                  height: 48,
                  padding: const EdgeInsets.only(left: 15, right: 4),
                  child: Row(
                    children: [
                      const Icon(
                        Icons.drag_indicator,
                        color: Colors.white38,
                        size: 18,
                      ),
                      const SizedBox(width: 7),
                      const Expanded(
                        child: Row(
                          children: [
                            Text(
                              'Clipboard',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.w700,
                                fontSize: 16,
                              ),
                            ),
                            SizedBox(width: 8),
                            Text(
                              'AUTO',
                              style: TextStyle(
                                color: Colors.white38,
                                fontWeight: FontWeight.w700,
                                fontSize: 9,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        tooltip: 'Limpar histórico',
                        onPressed: () async {
                          items.clear();
                          await _saveItems();
                          if (mounted) setState(() {});
                        },
                        icon: const Icon(
                          Icons.delete_outline,
                          color: Colors.white70,
                        ),
                      ),
                      IconButton(
                        tooltip: 'Fechar',
                        onPressed: widget.onClose,
                        icon: const Icon(Icons.close, color: Colors.white70),
                      ),
                    ],
                  ),
                ),
              ),
              const Divider(height: 1, color: Colors.white12),
              Expanded(
                child: items.isEmpty
                    ? const Center(
                        child: Padding(
                          padding: EdgeInsets.all(18),
                          child: Text(
                            'Sem histórico. O texto copiado entra aqui automaticamente.',
                            textAlign: TextAlign.center,
                            style: TextStyle(color: Colors.white60),
                          ),
                        ),
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 6,
                        ),
                        itemCount: items.length,
                        separatorBuilder: (_, __) =>
                            const Divider(height: 1, color: Colors.white10),
                        itemBuilder: (_, i) {
                          final value = items[i];
                          final preview = value.replaceAll(RegExp(r'\s+'), ' ');
                          return ListTile(
                            dense: true,
                            minLeadingWidth: 24,
                            leading: const Icon(
                              Icons.content_paste,
                              color: Colors.white54,
                              size: 18,
                            ),
                            title: Text(
                              preview.length > 105
                                  ? '${preview.substring(0, 105)}…'
                                  : preview,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                              ),
                            ),
                            trailing: IconButton(
                              icon: const Icon(
                                Icons.close,
                                color: Colors.white38,
                                size: 18,
                              ),
                              onPressed: () async {
                                items.removeAt(i);
                                await _saveItems();
                                if (mounted) setState(() {});
                              },
                            ),
                            onTap: () async {
                              await SilrustClipboard.remember(
                                  widget.peer, value);
                              await widget.onPaste(value);
                              if (mounted) {
                                setState(() {
                                  items.remove(value);
                                  items.insert(0, value);
                                });
                              }
                            },
                          );
                        },
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
