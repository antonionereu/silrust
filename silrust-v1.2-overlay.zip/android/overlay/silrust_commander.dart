import 'package:flutter/material.dart';
import 'package:flutter_hbb/common.dart';
import 'package:flutter_hbb/models/file_model.dart';
import 'package:flutter_hbb/models/model.dart';
import 'package:flutter_hbb/models/platform_model.dart';
import 'package:get/get.dart';
import 'package:uuid/uuid.dart';

class SilrustCommander {
  static Future<void> show(
    BuildContext context, {
    required String peerId,
    required String? connToken,
    required bool? forceRelay,
  }) async {
    await showGeneralDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Ficheiros',
      barrierColor: const Color(0x99000000),
      transitionDuration: const Duration(milliseconds: 140),
      pageBuilder: (context, _, __) => _SilrustCommanderWindow(
        peerId: peerId,
        connToken: connToken,
        forceRelay: forceRelay,
      ),
      transitionBuilder: (context, animation, _, child) => FadeTransition(
        opacity: animation,
        child: ScaleTransition(
          scale: Tween<double>(begin: 0.98, end: 1).animate(animation),
          child: child,
        ),
      ),
    );
  }
}

class _SilrustCommanderWindow extends StatefulWidget {
  const _SilrustCommanderWindow({
    required this.peerId,
    required this.connToken,
    required this.forceRelay,
  });

  final String peerId;
  final String? connToken;
  final bool? forceRelay;

  @override
  State<_SilrustCommanderWindow> createState() =>
      _SilrustCommanderWindowState();
}

class _SilrustCommanderWindowState extends State<_SilrustCommanderWindow> {
  late final FFI _ffi;
  final _wakelockKey = UniqueKey();
  late final String _eventHandlerKey;
  static const _fileEvents = <String>{
    'peer_info',
    'sync_peer_info',
    'connection_ready',
    'permission',
    'msgbox',
    'toast',
    'file_dir',
    'empty_dirs',
    'job_progress',
    'job_done',
    'job_error',
    'override_file_confirm',
    'load_last_job',
    'update_folder_files',
  };
  String? _selectedLocalPath;
  String? _selectedRemotePath;

  FileModel get model => _ffi.fileModel;
  FileController get local => model.localController;
  FileController get remote => model.remoteController;

  @override
  void initState() {
    super.initState();

    // A dedicated session ID keeps the file-transfer connection completely
    // separate from the live remote-desktop session underneath this dialog.
    _ffi = FFI(Uuid().v4obj());
    _eventHandlerKey = 'silrust_ft_${Uuid().v4()}';

    // Keep the live desktop callback in place. RustDesk mobile normally has a
    // single catch-all callback, so replacing it here would freeze/corrupt the
    // active desktop session. We intercept only file-transfer events and route
    // them to this dedicated FFI instance.
    final fileHandler =
        _ffi.ffiModel.startEventListener(_ffi.sessionId, widget.peerId);
    for (final eventName in _fileEvents) {
      platformFFI.registerEventHandler(eventName, _eventHandlerKey, fileHandler);
    }

    _ffi.start(
      widget.peerId,
      isFileTransfer: true,
      connToken: widget.connToken,
      forceRelay: widget.forceRelay,
    );
    WakelockManager.enable(_wakelockKey);
  }

  @override
  void dispose() {
    for (final eventName in _fileEvents) {
      platformFFI.unregisterEventHandler(eventName, _eventHandlerKey);
    }
    model.close().whenComplete(() {
      _ffi.close();
      WakelockManager.disable(_wakelockKey);
    });
    super.dispose();
  }

  Entry? _selectedEntry(FileController controller, String? path) {
    if (path == null) return null;
    for (final entry in controller.directory.value.entries) {
      if (entry.path == path) return entry;
    }
    return null;
  }

  void _select(bool isLocal, Entry entry) {
    setState(() {
      if (isLocal) {
        _selectedLocalPath = entry.path;
      } else {
        _selectedRemotePath = entry.path;
      }
    });
  }

  Future<void> _transfer({required bool localToRemote}) async {
    final source = localToRemote ? local : remote;
    final destination = localToRemote ? remote : local;
    final selectedPath = localToRemote ? _selectedLocalPath : _selectedRemotePath;
    final entry = _selectedEntry(source, selectedPath);
    if (entry == null) return;

    final items = SelectedItems(isLocal: source.isLocal)..add(entry);
    await source.sendFiles(items, destination.directoryData());

    if (!mounted) return;
    setState(() {
      if (localToRemote) {
        _selectedLocalPath = null;
      } else {
        _selectedRemotePath = null;
      }
    });
  }

  Widget _toolButton({
    required IconData icon,
    required String tooltip,
    required VoidCallback onPressed,
  }) {
    return IconButton(
      visualDensity: VisualDensity.compact,
      padding: const EdgeInsets.all(4),
      constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
      iconSize: 19,
      tooltip: tooltip,
      onPressed: onPressed,
      icon: Icon(icon),
    );
  }

  Widget _pane({
    required String title,
    required FileController controller,
    required bool isLocal,
  }) {
    final selectedPath = isLocal ? _selectedLocalPath : _selectedRemotePath;

    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Theme.of(context).dividerColor),
        borderRadius: BorderRadius.circular(8),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Container(
            height: 38,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            color: Theme.of(context).colorScheme.surfaceContainerHighest,
            child: Row(
              children: [
                Icon(isLocal ? Icons.phone_android : Icons.computer, size: 18),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w700),
                  ),
                ),
                _toolButton(
                  icon: Icons.arrow_back,
                  tooltip: 'Voltar',
                  onPressed: controller.goBack,
                ),
                _toolButton(
                  icon: Icons.arrow_upward,
                  tooltip: 'Subir',
                  onPressed: controller.goToParentDirectory,
                ),
                _toolButton(
                  icon: isLocal ? Icons.home_outlined : Icons.storage_outlined,
                  tooltip: isLocal ? 'Início' : 'Discos',
                  onPressed: controller.goToHomeDirectory,
                ),
                _toolButton(
                  icon: Icons.refresh,
                  tooltip: 'Atualizar',
                  onPressed: () => controller.refresh(),
                ),
              ],
            ),
          ),
          Obx(() {
            final path = controller.directory.value.path;
            return Container(
              width: double.infinity,
              height: 30,
              alignment: Alignment.centerLeft,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              decoration: BoxDecoration(
                border: Border(
                  top: BorderSide(color: Theme.of(context).dividerColor),
                  bottom: BorderSide(color: Theme.of(context).dividerColor),
                ),
              ),
              child: Text(
                path.isEmpty ? (isLocal ? 'Android' : 'PC remoto') : path,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 11),
              ),
            );
          }),
          Expanded(
            child: Obx(() {
              final entries = controller.directory.value.entries;
              if (entries.isEmpty) {
                return const Center(
                  child: Text('A carregar…', style: TextStyle(fontSize: 12)),
                );
              }
              return ListView.builder(
                padding: EdgeInsets.zero,
                itemCount: entries.length,
                itemBuilder: (context, index) {
                  final entry = entries[index];
                  final selected = entry.path == selectedPath;
                  return Material(
                    color: selected
                        ? Theme.of(context).colorScheme.primaryContainer
                        : Colors.transparent,
                    child: InkWell(
                      onTap: () {
                        if (entry.isDirectory || entry.isDrive) {
                          controller.openDirectory(entry.path);
                          setState(() {
                            if (isLocal) {
                              _selectedLocalPath = null;
                            } else {
                              _selectedRemotePath = null;
                            }
                          });
                        } else {
                          _select(isLocal, entry);
                        }
                      },
                      onLongPress: entry.isDrive ? null : () => _select(isLocal, entry),
                      child: SizedBox(
                        height: 38,
                        child: Row(
                          children: [
                            const SizedBox(width: 7),
                            Icon(
                              entry.isDrive
                                  ? Icons.storage
                                  : entry.isDirectory
                                      ? Icons.folder
                                      : Icons.insert_drive_file_outlined,
                              size: 19,
                            ),
                            const SizedBox(width: 7),
                            Expanded(
                              child: Text(
                                entry.name,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontSize: 12),
                              ),
                            ),
                            if (entry.isFile)
                              Padding(
                                padding: const EdgeInsets.only(right: 7),
                                child: Text(
                                  readableFileSize(entry.size.toDouble()),
                                  style: TextStyle(
                                    fontSize: 10,
                                    color: Theme.of(context).hintColor,
                                  ),
                                ),
                              ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              );
            }),
          ),
          Container(
            height: 26,
            alignment: Alignment.centerLeft,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            decoration: BoxDecoration(
              border: Border(top: BorderSide(color: Theme.of(context).dividerColor)),
            ),
            child: Text(
              isLocal
                  ? 'Toque: abrir/selecionar · manter: selecionar pasta'
                  : 'PC remoto · manter numa pasta para a selecionar',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 9, color: Theme.of(context).hintColor),
            ),
          ),
        ],
      ),
    );
  }

  Widget _transferButtons() {
    final canSend = _selectedEntry(local, _selectedLocalPath) != null;
    final canReceive = _selectedEntry(remote, _selectedRemotePath) != null;

    return SizedBox(
      width: 46,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton.filledTonal(
            tooltip: 'Enviar para o PC',
            onPressed: canSend ? () => _transfer(localToRemote: true) : null,
            icon: const Icon(Icons.arrow_forward, size: 20),
          ),
          const SizedBox(height: 12),
          IconButton.filledTonal(
            tooltip: 'Receber no Android',
            onPressed: canReceive ? () => _transfer(localToRemote: false) : null,
            icon: const Icon(Icons.arrow_back, size: 20),
          ),
        ],
      ),
    );
  }

  Widget _transferStatus() {
    return Obx(() {
      final jobs = model.jobController.jobTable;
      if (jobs.isEmpty) {
        return const SizedBox(
          height: 34,
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text('Sem transferências em curso', style: TextStyle(fontSize: 11)),
          ),
        );
      }

      final job = jobs.last;
      final inProgress = job.state == JobState.inProgress;
      return SizedBox(
        height: 40,
        child: Row(
          children: [
            SizedBox(
              width: 18,
              height: 18,
              child: inProgress
                  ? CircularProgressIndicator(
                      strokeWidth: 2,
                      value: job.percent > 0 ? job.percent : null,
                    )
                  : Icon(
                      job.state == JobState.error ? Icons.error_outline : Icons.check_circle_outline,
                      size: 18,
                    ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                '${job.jobName} · ${job.getStatus()}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 11),
              ),
            ),
            if (inProgress)
              IconButton(
                tooltip: 'Cancelar',
                onPressed: () => model.jobController.cancelJob(job.id),
                icon: const Icon(Icons.close, size: 18),
              ),
          ],
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final width = size.width * 0.96;
    final height = size.height * 0.90;

    return SafeArea(
      child: Center(
        child: Material(
          color: Theme.of(context).dialogBackgroundColor,
          elevation: 18,
          borderRadius: BorderRadius.circular(12),
          clipBehavior: Clip.antiAlias,
          child: SizedBox(
            width: width,
            height: height,
            child: Column(
              children: [
                SizedBox(
                  height: 42,
                  child: Row(
                    children: [
                      const SizedBox(width: 12),
                      const Icon(Icons.swap_horiz, size: 20),
                      const SizedBox(width: 7),
                      const Expanded(
                        child: Text(
                          'Ficheiros · Android ↔ PC remoto',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                      IconButton(
                        tooltip: 'Fechar',
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.close),
                      ),
                      const SizedBox(width: 3),
                    ],
                  ),
                ),
                Divider(height: 1, color: Theme.of(context).dividerColor),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(8),
                    child: Row(
                      children: [
                        Expanded(
                          child: _pane(
                            title: 'ANDROID',
                            controller: local,
                            isLocal: true,
                          ),
                        ),
                        _transferButtons(),
                        Expanded(
                          child: _pane(
                            title: 'PC REMOTO',
                            controller: remote,
                            isLocal: false,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 0, 10, 5),
                  child: _transferStatus(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
