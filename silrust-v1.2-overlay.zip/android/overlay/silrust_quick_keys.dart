import 'package:flutter/material.dart';

class SilrustQuickKeys extends StatelessWidget {
  const SilrustQuickKeys({
    super.key,
    required this.onKey,
  });

  final ValueChanged<String> onKey;

  Widget _key({String? label, IconData? icon, required String keyName}) {
    return Material(
      color: const Color(0xD016181C),
      borderRadius: BorderRadius.circular(8),
      elevation: 2,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: () => onKey(keyName),
        child: SizedBox(
          width: 52,
          height: 34,
          child: Center(
            child: icon != null
                ? Icon(icon, size: 20, color: Colors.white)
                : Text(
                    label ?? '',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Requirement: these three keys exist only below 600 px. At 600 px and
    // above they disappear completely.
    if (MediaQuery.of(context).size.width >= 600) {
      return const SizedBox.shrink();
    }

    return SafeArea(
      child: Align(
        alignment: Alignment.bottomCenter,
        child: Padding(
          padding: const EdgeInsets.only(bottom: 4),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _key(label: 'TAB', keyName: 'VK_TAB'),
              const SizedBox(width: 5),
              _key(icon: Icons.keyboard_arrow_left, keyName: 'VK_LEFT'),
              const SizedBox(width: 5),
              _key(icon: Icons.keyboard_arrow_right, keyName: 'VK_RIGHT'),
            ],
          ),
        ),
      ),
    );
  }
}
