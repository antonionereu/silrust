import 'dart:math' as math;

import 'package:flutter/material.dart';

class SilrustMousePanel {
  static OverlayEntry? _entry;

  static void dismiss() {
    _entry?.remove();
    _entry = null;
  }

  static void toggle(
    BuildContext context, {
    required bool touchMode,
    required bool showVirtualMouse,
    required Future<void> Function(bool touchMode) onMode,
    required Future<void> Function() onVirtualMouse,
  }) {
    if (_entry != null) {
      dismiss();
      return;
    }

    final overlay = Overlay.of(context, rootOverlay: true);
    late OverlayEntry entry;
    entry = OverlayEntry(
      builder: (ctx) => _SilrustMouseWindow(
        initialTouchMode: touchMode,
        initialVirtualMouse: showVirtualMouse,
        onMode: onMode,
        onVirtualMouse: onVirtualMouse,
        onClose: dismiss,
      ),
    );
    _entry = entry;
    overlay.insert(entry);
  }
}

class _SilrustMouseWindow extends StatefulWidget {
  const _SilrustMouseWindow({
    required this.initialTouchMode,
    required this.initialVirtualMouse,
    required this.onMode,
    required this.onVirtualMouse,
    required this.onClose,
  });

  final bool initialTouchMode;
  final bool initialVirtualMouse;
  final Future<void> Function(bool touchMode) onMode;
  final Future<void> Function() onVirtualMouse;
  final VoidCallback onClose;

  @override
  State<_SilrustMouseWindow> createState() => _SilrustMouseWindowState();
}

class _SilrustMouseWindowState extends State<_SilrustMouseWindow> {
  late bool touchMode;
  late bool virtualMouse;

  @override
  void initState() {
    super.initState();
    touchMode = widget.initialTouchMode;
    virtualMouse = widget.initialVirtualMouse;
  }

  Widget _modeButton(
    BuildContext context,
    String label,
    IconData icon,
    bool selected,
    bool value,
  ) {
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: () async {
          if (touchMode == value) return;
          await widget.onMode(value);
          if (mounted) setState(() => touchMode = value);
        },
        child: Container(
          height: 42,
          decoration: BoxDecoration(
            color: selected
                ? Theme.of(context).colorScheme.primary
                : Colors.white10,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 18, color: Colors.white),
              const SizedBox(width: 7),
              Text(
                label,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _gesture(IconData icon, String title, String subtitle) {
    return SizedBox(
      width: 122,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 6),
        child: Row(
          children: [
            Icon(icon, size: 20, color: Colors.white54),
            const SizedBox(width: 7),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(
                    subtitle,
                    style: const TextStyle(
                      color: Colors.white54,
                      fontSize: 9.5,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final panelW = math.min(330.0, math.max(280.0, size.width * .25));

    return Positioned(
      right: 62,
      top: math.max(12, (size.height - 280) / 2),
      width: panelW,
      child: Material(
        color: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
          decoration: BoxDecoration(
            color: const Color(0xE31A1C20),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white12),
            boxShadow: const [
              BoxShadow(
                color: Color(0x66000000),
                blurRadius: 18,
                offset: Offset(0, 7),
              ),
            ],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  const Expanded(
                    child: Text(
                      'Controlo',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    onPressed: widget.onClose,
                    icon: const Icon(Icons.close, color: Colors.white70),
                  ),
                ],
              ),
              Row(
                children: [
                  _modeButton(
                    context,
                    'Modo rato',
                    Icons.mouse,
                    !touchMode,
                    false,
                  ),
                  const SizedBox(width: 8),
                  _modeButton(
                    context,
                    'Modo toque',
                    Icons.touch_app,
                    touchMode,
                    true,
                  ),
                ],
              ),
              const SizedBox(height: 6),
              InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: () async {
                  await widget.onVirtualMouse();
                  if (mounted) {
                    setState(() => virtualMouse = !virtualMouse);
                  }
                },
                child: Row(
                  children: [
                    Checkbox(
                      value: virtualMouse,
                      onChanged: (_) async {
                        await widget.onVirtualMouse();
                        if (mounted) {
                          setState(() => virtualMouse = !virtualMouse);
                        }
                      },
                    ),
                    const Text(
                      'Mostrar rato virtual',
                      style: TextStyle(color: Colors.white),
                    ),
                  ],
                ),
              ),
              const Divider(color: Colors.white12),
              Wrap(
                spacing: 8,
                runSpacing: 0,
                children: [
                  _gesture(Icons.touch_app, '1 toque', 'Botão esquerdo'),
                  _gesture(Icons.ads_click, 'Toque longo', 'Botão direito'),
                  _gesture(Icons.swipe, '2 dedos', 'Mover ecrã'),
                  _gesture(Icons.zoom_in, 'Pinch', 'Zoom'),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
