#!/usr/bin/env python3
from __future__ import annotations

import re
import shutil
import sys
from pathlib import Path

if len(sys.argv) != 2:
    raise SystemExit("Uso: patch_silrust.py <rustdesk-source>")

root = Path(sys.argv[1]).resolve()
flutter = root / "flutter"
remote = flutter / "lib/mobile/pages/remote_page.dart"
pubspec = flutter / "pubspec.yaml"
manifest = flutter / "android/app/src/main/AndroidManifest.xml"
widgets = flutter / "lib/mobile/widgets"

for p in (remote, pubspec, manifest):
    if not p.exists():
        raise SystemExit(f"Falta upstream esperado: {p}")

text = remote.read_text(encoding="utf-8")

for anchor in [
    "class _RemotePageState",
    "void openKeyboard()",
    "class _KeyHelpToolsState",
    "Widget build(BuildContext context)",
]:
    if anchor not in text:
        raise SystemExit(f"Anchor RustDesk 1.5.0 nao encontrado: {anchor}")

widgets.mkdir(parents=True, exist_ok=True)
overlay = Path(__file__).parent / "overlay"
shutil.copy2(overlay / "silrust_controls.dart", widgets / "silrust_controls.dart")
shutil.copy2(overlay / "silrust_clipboard.dart", widgets / "silrust_clipboard.dart")

ps = pubspec.read_text(encoding="utf-8")
if not re.search(r"^\s*shared_preferences\s*:", ps, re.M):
    m = re.search(r"^dependencies:\s*$", ps, re.M)
    if not m:
        raise SystemExit("dependencies: nao encontrado")
    ps = ps[:m.end()] + "\n  shared_preferences: 2.3.2" + ps[m.end():]
pubspec.write_text(ps, encoding="utf-8")

ms = manifest.read_text(encoding="utf-8")
ms = ms.replace('android:label="RustDesk"', 'android:label="silrust"')
manifest.write_text(ms, encoding="utf-8")

service_import = "import 'package:flutter/services.dart';"
if service_import not in text:
    raise SystemExit("flutter/services.dart import nao encontrado")

text = text.replace(
    service_import,
    service_import
    + "\nimport '../widgets/silrust_controls.dart';"
    + "\nimport '../widgets/silrust_clipboard.dart';",
    1,
)

# Remove the RustDesk modifier/helper toolbar shown above the soft keyboard.
key_state = text.index("class _KeyHelpToolsState")
key_build = text.find("Widget build(BuildContext context)", key_state)
if key_build < 0:
    raise SystemExit("_KeyHelpToolsState.build nao encontrado")
key_brace = text.find("{", key_build)
if key_brace < 0:
    raise SystemExit("brace de KeyHelpTools.build nao encontrado")
text = (
    text[:key_brace + 1]
    + "\n    return const SizedBox.shrink(); // SILRUST: toolbar Ctrl/Alt/Shift/etc removida\n"
    + text[key_brace + 1:]
)

open_keyboard = text.find("  void openKeyboard()")
if open_keyboard < 0:
    raise SystemExit("openKeyboard anchor nao encontrado")

helpers = r'''
  Future<void> _silrustPaste(String value) async {
    if (value.isEmpty) return;
    await Clipboard.setData(ClipboardData(text: value));
    await gFFI.invokeMethod("try_sync_clipboard");
    await Future.delayed(const Duration(milliseconds: 80));
    final isMac = gFFI.ffiModel.pi.platform == kPeerPlatformMacOS;
    inputModel.inputKey(
      'VK_V',
      press: true,
      ctrlOverride: !isMac,
      commandOverride: isMac,
      altOverride: false,
      shiftOverride: false,
    );
  }

  void _silrustMore() {
    // v1.0a: preserve upstream actions as fallback.
    try {
      gFFI.invokeMethod("show_remote_actions");
    } catch (_) {}
  }

  Future<void> _silrustEnd() async {
    await gFFI.close();
    if (mounted && Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    }
  }

'''
text = text[:open_keyboard] + helpers + text[open_keyboard:]

# Wrap only _RemotePageState.build.
state_start = text.index("class _RemotePageState")
build_pos = text.find("Widget build(BuildContext context)", state_start)
if build_pos < 0:
    raise SystemExit("_RemotePageState.build nao encontrado")

text = (
    text[:build_pos]
    + "Widget _silrustUpstreamBuild(BuildContext context)"
    + text[build_pos + len("Widget build(BuildContext context)"):]
)

wrapper = r'''
  @override
  Widget build(BuildContext context) {
    final upstream = _silrustUpstreamBuild(context);

    if (defaultTargetPlatform != TargetPlatform.android) {
      return upstream;
    }

    return Stack(
      fit: StackFit.expand,
      children: [
        upstream,
        SilrustControls(
          onKeyboard: openKeyboard,
          onClipboard: () {
            SilrustClipboard.show(
              context,
              widget.id,
              _silrustPaste,
            );
          },
          onMore: _silrustMore,
          onEnd: _silrustEnd,
        ),
      ],
    );
  }

'''
text = text[:build_pos] + wrapper + text[build_pos:]

text = text.replace(
    "class _RemotePageState",
    "// SILRUST_V1_0A\nclass _RemotePageState",
    1,
)

remote.write_text(text, encoding="utf-8")

(root / "SILRUST_PATCH.txt").write_text(
    "silrust v1.0a\n"
    "Base RustDesk 1.5.0\n"
    "Core/protocol unchanged.\n"
    "Android floating controls + keyboard helper suppressed + clipboard shelf.\n",
    encoding="utf-8",
)

print("OK: patch silrust v1.0a aplicado.")
