param(
    [Parameter(Mandatory=$true)]
    [string]$ProjectRoot
)

$ErrorActionPreference = "Stop"
$ProjectRoot = ($ProjectRoot -replace '[\u0000-\u001F]', '').Trim().Trim('"').TrimEnd('\','/')
$ProjectRoot = [IO.Path]::GetFullPath($ProjectRoot)
$Log = Join-Path $ProjectRoot "build-silrust.log"

Start-Transcript -Path $Log -Force | Out-Null

function Step([string]$s) { Write-Host ""; Write-Host "==> $s" -ForegroundColor Cyan }
function Fail([string]$s,[int]$c=20) {
    Write-Host ""; Write-Host "[ERRO] $s" -ForegroundColor Red
    try { Stop-Transcript | Out-Null } catch {}
    exit $c
}

try {
    Step "1/5 Verificar WSL"
    if (-not (Get-Command wsl.exe -ErrorAction SilentlyContinue)) {
        Write-Host "Instala com: wsl --install -d Ubuntu"
        Fail "WSL nao instalado." 10
    }

    Step "2/5 Procurar Ubuntu"
    $raw = & wsl.exe -l -q 2>$null
    $distros = @(
        $raw |
        ForEach-Object { ($_ -replace "`0","").Trim() } |
        Where-Object { $_ -match '^Ubuntu' }
    )
    if ($distros.Count -eq 0) {
        & wsl.exe -l -v
        Write-Host ""
        Write-Host "Instala com: wsl --install -d Ubuntu"
        Fail "Ubuntu nao instalado no WSL." 11
    }
    $Distro = $distros[0]
    Write-Host "Distro: $Distro" -ForegroundColor Green

    Step "3/5 Testar Ubuntu"
    & wsl.exe -d $Distro -- bash -lc "echo SILRUST_WSL_OK"
    if ($LASTEXITCODE -ne 0) {
        Fail "Abre Ubuntu pelo menu Iniciar e conclui primeiro a inicializacao." 12
    }

    Step "4/5 Converter caminho"
    $wslRoot = (& wsl.exe -d $Distro -- wslpath -a "$ProjectRoot").Trim()
    if ([string]::IsNullOrWhiteSpace($wslRoot)) { Fail "Falhou wslpath." 13 }
    Write-Host "WSL: $wslRoot"

    Step "5/5 Compilar silrust"
    $cmd = "set -e; bash '$wslRoot/android/build-silrust-wsl.sh' '$wslRoot'"
    & wsl.exe -d $Distro -- bash -lc $cmd
    if ($LASTEXITCODE -ne 0) { Fail "Build Linux falhou com codigo $LASTEXITCODE." 20 }

    $apk = Join-Path $ProjectRoot "dist\silrust-v1.0a-arm64.apk"
    if (-not (Test-Path $apk)) { Fail "APK nao encontrada em dist." 21 }

    $h = (Get-FileHash -Algorithm SHA256 $apk).Hash
    Write-Host ""
    Write-Host "APK: $apk" -ForegroundColor Green
    Write-Host "SHA-256: $h"
    Stop-Transcript | Out-Null
    exit 0
}
catch {
    Write-Host ""
    Write-Host "[EXCECAO] $($_.Exception.Message)" -ForegroundColor Red
    try { Stop-Transcript | Out-Null } catch {}
    exit 99
}
