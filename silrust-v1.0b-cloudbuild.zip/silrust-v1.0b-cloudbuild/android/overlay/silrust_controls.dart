import 'package:flutter/material.dart';

class SilrustControls extends StatefulWidget {
  const SilrustControls({
    super.key,
    required this.onKeyboard,
    required this.onClipboard,
    required this.onMore,
    required this.onEnd,
  });

  final VoidCallback onKeyboard;
  final VoidCallback onClipboard;
  final VoidCallback onMore;
  final VoidCallback onEnd;

  @override
  State<SilrustControls> createState() => _SilrustControlsState();
}

class _SilrustControlsState extends State<SilrustControls> {
  bool collapsed = false;

  Widget button(
    IconData icon,
    String tooltip,
    VoidCallback onTap, {
    bool danger = false,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Tooltip(
        message: tooltip,
        child: Material(
          color: danger
              ? const Color(0xAA8B2020)
              : const Color(0x9914161A),
          borderRadius: BorderRadius.circular(15),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(15),
            child: SizedBox(
              width: 44,
              height: 44,
              child: Icon(icon, color: Colors.white, size: 21),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Align(
        alignment: Alignment.centerRight,
        child: Padding(
          padding: const EdgeInsets.only(right: 7),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              button(
                collapsed ? Icons.chevron_left : Icons.chevron_right,
                collapsed ? 'Mostrar' : 'Ocultar',
                () => setState(() => collapsed = !collapsed),
              ),
              if (!collapsed) ...[
                button(Icons.keyboard_alt_outlined, 'Teclado', widget.onKeyboard),
                button(Icons.content_paste_outlined, 'Clipboard', widget.onClipboard),
                button(Icons.more_horiz, 'Mais', widget.onMore),
                button(Icons.close, 'Terminar', widget.onEnd, danger: true),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
