import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SilrustClipboard {
  static const int maxItems = 40;

  static String _key(String peer) => 'silrust.clipboard.$peer';

  static Future<List<String>> load(String peer) async {
    final p = await SharedPreferences.getInstance();
    return p.getStringList(_key(peer)) ?? <String>[];
  }

  static Future<List<String>> remember(String peer, String text) async {
    if (text.trim().isEmpty) return load(peer);
    final p = await SharedPreferences.getInstance();
    final list = await load(peer);
    list.remove(text);
    list.insert(0, text);
    while (list.length > maxItems) {
      list.removeLast();
    }
    await p.setStringList(_key(peer), list);
    return list;
  }

  static Future<void> show(
    BuildContext context,
    String peer,
    Future<void> Function(String) onPaste,
  ) async {
    var items = await load(peer);
    if (!context.mounted) return;

    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) {
          return SafeArea(
            child: Container(
              margin: const EdgeInsets.all(8),
              constraints: BoxConstraints(
                maxHeight: MediaQuery.sizeOf(ctx).height * .68,
              ),
              decoration: BoxDecoration(
                color: const Color(0xF21B1D21),
                borderRadius: BorderRadius.circular(22),
              ),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 10, 8, 6),
                    child: Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'Clipboard',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w700,
                              fontSize: 17,
                            ),
                          ),
                        ),
                        IconButton(
                          tooltip: 'Guardar clipboard atual',
                          onPressed: () async {
                            final d = await Clipboard.getData(Clipboard.kTextPlain);
                            final text = d?.text ?? '';
                            items = await remember(peer, text);
                            setState(() {});
                          },
                          icon: const Icon(Icons.add, color: Colors.white),
                        ),
                        IconButton(
                          tooltip: 'Limpar',
                          onPressed: () async {
                            final p = await SharedPreferences.getInstance();
                            await p.remove(_key(peer));
                            items = <String>[];
                            setState(() {});
                          },
                          icon: const Icon(Icons.delete_outline, color: Colors.white70),
                        ),
                      ],
                    ),
                  ),
                  if (items.isEmpty)
                    const Padding(
                      padding: EdgeInsets.fromLTRB(24, 18, 24, 28),
                      child: Text(
                        'Sem histórico. Copia texto no Android e toca em +.',
                        style: TextStyle(color: Colors.white60),
                      ),
                    )
                  else
                    Flexible(
                      child: ListView.separated(
                        shrinkWrap: true,
                        padding: const EdgeInsets.fromLTRB(8, 0, 8, 10),
                        itemCount: items.length,
                        separatorBuilder: (_, __) =>
                            const Divider(height: 1, color: Colors.white12),
                        itemBuilder: (_, i) {
                          final value = items[i];
                          final preview = value.replaceAll(RegExp(r'\s+'), ' ');
                          return ListTile(
                            dense: true,
                            title: Text(
                              preview.length > 100
                                  ? '${preview.substring(0, 100)}…'
                                  : preview,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                              ),
                            ),
                            leading: const Icon(
                              Icons.content_paste,
                              color: Colors.white54,
                              size: 19,
                            ),
                            trailing: IconButton(
                              icon: const Icon(
                                Icons.close,
                                color: Colors.white38,
                                size: 18,
                              ),
                              onPressed: () async {
                                items.removeAt(i);
                                final p = await SharedPreferences.getInstance();
                                await p.setStringList(_key(peer), items);
                                setState(() {});
                              },
                            ),
                            onTap: () async {
                              await remember(peer, value);
                              await onPaste(value);
                              if (ctx.mounted) Navigator.of(ctx).pop();
                            },
                          );
                        },
                      ),
                    ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
