#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:?project root missing}"
TOOLS="$ROOT/.tools"
WORK="$ROOT/work"
SRC="$WORK/rustdesk"
DIST="$ROOT/dist"

RUSTDESK_REF="1.5.0"
FLUTTER_REF="3.24.5"
NDK_VERSION="28.2.13676358"

say(){ printf "\n\033[1;36m==> %s\033[0m\n" "$*"; }
die(){ printf "\n\033[1;31mERRO: %s\033[0m\n" "$*" >&2; exit 1; }

mkdir -p "$TOOLS" "$WORK" "$DIST"

say "Dependencias Ubuntu"
sudo apt-get update
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y \
  git curl wget unzip zip ca-certificates build-essential cmake ninja-build \
  nasm yasm pkg-config clang llvm libclang-dev libssl-dev \
  python3 python3-pip python3-setuptools openjdk-17-jdk jq rsync patchelf

export JAVA_HOME="${JAVA_HOME:-/usr/lib/jvm/java-17-openjdk-amd64}"
export PATH="$JAVA_HOME/bin:$PATH"

say "Android SDK"
SDK="$TOOLS/android-sdk"
mkdir -p "$SDK/cmdline-tools"
if [[ ! -x "$SDK/cmdline-tools/latest/bin/sdkmanager" ]]; then
  ZIP="$TOOLS/cmdline-tools.zip"
  curl -L --fail --retry 3 \
    "https://dl.google.com/android/repository/commandlinetools-linux-15859902_latest.zip" \
    -o "$ZIP"
  rm -rf "$TOOLS/cmdline-unpack"
  mkdir -p "$TOOLS/cmdline-unpack"
  unzip -q "$ZIP" -d "$TOOLS/cmdline-unpack"
  rm -rf "$SDK/cmdline-tools/latest"
  mv "$TOOLS/cmdline-unpack/cmdline-tools" "$SDK/cmdline-tools/latest"
fi

export ANDROID_HOME="$SDK"
export ANDROID_SDK_ROOT="$SDK"
export PATH="$SDK/cmdline-tools/latest/bin:$SDK/platform-tools:$PATH"

yes | sdkmanager --licenses >/dev/null || true
sdkmanager \
  "platform-tools" \
  "platforms;android-35" \
  "platforms;android-36" \
  "build-tools;35.0.0" \
  "build-tools;36.0.0" \
  "ndk;$NDK_VERSION"

export ANDROID_NDK_HOME="$SDK/ndk/$NDK_VERSION"
export ANDROID_NDK_ROOT="$ANDROID_NDK_HOME"

say "Rust"
if [[ ! -x "$HOME/.cargo/bin/rustup" ]]; then
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --default-toolchain 1.75.0
fi
source "$HOME/.cargo/env"
rustup toolchain install 1.75.0
rustup default 1.75.0
rustup target add aarch64-linux-android
if ! cargo ndk --version 2>/dev/null | grep -q "3.1.2"; then
  cargo install cargo-ndk --version 3.1.2 --locked --force
fi

say "Flutter $FLUTTER_REF"
FLUTTER="$TOOLS/flutter"
if [[ ! -d "$FLUTTER/.git" ]]; then
  git clone --depth 1 --branch "$FLUTTER_REF" https://github.com/flutter/flutter.git "$FLUTTER"
else
  git -C "$FLUTTER" fetch --depth 1 origin "$FLUTTER_REF"
  git -C "$FLUTTER" checkout -f "$FLUTTER_REF"
fi
export PATH="$FLUTTER/bin:$PATH"
flutter config --no-analytics >/dev/null
flutter precache --android

say "vcpkg"
VCPKG="$TOOLS/vcpkg"
if [[ ! -d "$VCPKG/.git" ]]; then
  git clone https://github.com/microsoft/vcpkg.git "$VCPKG"
fi
"$VCPKG/bootstrap-vcpkg.sh" -disableMetrics
export VCPKG_ROOT="$VCPKG"

say "RustDesk $RUSTDESK_REF"
rm -rf "$SRC"
git clone --branch "$RUSTDESK_REF" --depth 1 --recurse-submodules --shallow-submodules \
  https://github.com/rustdesk/rustdesk.git "$SRC"

say "Aplicar silrust"
python3 "$ROOT/android/patch_silrust.py" "$SRC"

say "Flutter packages"
cd "$SRC/flutter"
flutter pub get

say "Dependencias nativas"
cd "$SRC"
bash flutter/build_android_deps.sh arm64-v8a

say "Core Rust"
cargo ndk \
  --platform 21 \
  --target aarch64-linux-android \
  --bindgen \
  build --locked --release --features "flutter,hwcodec"

JNI="$SRC/flutter/android/app/src/main/jniLibs/arm64-v8a"
mkdir -p "$JNI"
cp "$SRC/target/aarch64-linux-android/release/liblibrustdesk.so" "$JNI/librustdesk.so"

LIBCPP="$(find "$ANDROID_NDK_HOME" -name libc++_shared.so -path '*aarch64*' -print -quit)"
[[ -n "$LIBCPP" ]] || die "libc++_shared.so nao encontrado"
cp "$LIBCPP" "$JNI/libc++_shared.so"

say "APK"
cd "$SRC/flutter"
flutter build apk --release --target-platform android-arm64

APK="$SRC/flutter/build/app/outputs/flutter-apk/app-release.apk"
[[ -f "$APK" ]] || die "app-release.apk nao foi criada"
cp "$APK" "$DIST/silrust-v1.0a-arm64.apk"

sha256sum "$DIST/silrust-v1.0a-arm64.apk"
